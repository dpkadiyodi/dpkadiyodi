import { Component, OnInit } from '@angular/core';
import { ProductsService } from './products.service';
import { Product } from '../product';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {
  displayedColumns: any[] = ['prod_name', 'prod_price'];
  data: Product[] = [];
  isLoadingResults: boolean;
  constructor(private productService: ProductsService, private route: Router) { }

  ngOnInit() {
    this.getTableDetails();
  }

  getTableDetails() {
    this.isLoadingResults = true;
    this.data = [
      {id: 1,
      prod_name: 'ddd',
      prod_desc: 'ddd',
      prod_price: 52,
      updated_at: new Date()},
      {id: 1,
        prod_name: 'kkk',
        prod_desc: 'ddlrkl34rkl3',
        prod_price: 52,
        updated_at: new Date()}
    ];
    this.productService.getProducts().subscribe(res => {
      this.isLoadingResults = false;
      // this.data = res;
     
    },
      (err: HttpErrorResponse) => {
        if (err instanceof HttpErrorResponse) {
          this.isLoadingResults = false;
        }
      }
    );
  }

  Add = (param) => {
    this.route.navigate([`products-add-edit/${param}`]);
  }
}
