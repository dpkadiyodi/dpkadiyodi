export class Product {
    id: number;
    prod_name: string;
    prod_desc: string;
    prod_price: number;
    updated_at: Date;
}