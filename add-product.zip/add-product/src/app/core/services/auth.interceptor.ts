import { Injectable } from '@angular/core';
import {
    HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { timeInterval, windowTime } from 'rxjs/operators';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    constructor() { }
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // let headers = new HttpHeaders();
        const apiUrl = environment.API.URL  + req.urlWithParams;
        let authHeader = new HttpHeaders();
        authHeader = authHeader.append('Content-Type', 'application/json').append('Authorization', 'Bearer SampleToken');

        // tslint:disable-next-line:object-literal-shorthand
        const anonymousReq = req.clone({ url: apiUrl, headers: authHeader });

        return next.handle(anonymousReq);
    }
}
