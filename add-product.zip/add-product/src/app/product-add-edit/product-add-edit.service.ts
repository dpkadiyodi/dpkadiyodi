import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
// const apiUrl = '/api/v1/products';

@Injectable({
    providedIn: 'root'
})
export class ProductAddEditService {

    constructor(private http: HttpClient) { }
    addProduct(param): Observable<any> {
        return this.http.get<any>('', param);
    }

    updateProduct(id, param): Observable<any> {
        return this.http.put<any>(`/${id}`, param);
    }

    deleteProduct(id): Observable<any> {
        return this.http.delete<any>(`/${id}`);
    }
}

