import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-add-edit',
  templateUrl: './product-add-edit.component.html',
  styleUrls: ['./product-add-edit.component.scss']
})
export class ProductAddEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
