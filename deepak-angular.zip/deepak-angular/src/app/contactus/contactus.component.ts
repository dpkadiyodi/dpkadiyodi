import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee/employee.service';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.scss']
})
export class ContactusComponent implements OnInit {
  testMsg: any;

  constructor(private employeeService: EmployeeService) {
  }

  ngOnInit() {
    this.employeeService.testMsg.subscribe(res => {
      this.testMsg = res;
    });
  }

}
