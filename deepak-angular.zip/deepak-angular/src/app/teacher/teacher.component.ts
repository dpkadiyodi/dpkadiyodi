import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee/employee.service';

@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.scss']
})
export class TeacherComponent implements OnInit {

  constructor(private route: Router, private employeeService: EmployeeService) { }

  ngOnInit() {
  }

  ContactUs = (param) => {
    this.employeeService.testMsg.next('testtttt');
    this.route.navigate([`nav/${param}`]);
  }
}


@Component({
  selector: 'app-ss',
  templateUrl: './teacher2.component.html',
  styleUrls: ['./teacher.component.scss']
})
export class Teacher2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
