import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { TeacherComponent } from './teacher/teacher.component';
import { ContactusComponent } from './contactus/contactus.component';

const routes: Routes = [
  {
    path: '', redirectTo: 'nav/Employee', pathMatch: 'full'
  },
  {
    path: 'nav', component: TeacherComponent, children: [
      {
      path: 'Employee', component: EmployeeComponent
    },
    {
      path: 'ContactUs', component: ContactusComponent
    }
  ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
