import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {
  EmployeeForm: FormGroup;
  dataSource: any[] = [{ Name: 'Dipin', RollNo: '1', DOB: '12-4-1992', Gender: 'Male' },
  { Name: 'Deepak', RollNo: '2', DOB: '12-4-1989', Gender: 'Male' }];
  displayedColumns: string[] = ['Name', 'RollNo', 'DOB', 'Gender'];
  constructor(private fb: FormBuilder, private ss: EmployeeService) {
    this.EmployeeForm = this.fb.group({
      EmployeeName: ['', Validators.required], EmployeeRollNo: ['', Validators.required],
      DOB: ['', Validators.required], Gender: ['', Validators.required]
    });
  }

  ngOnInit() {
  }
  submit = () => {
    this.ss.Submit(this.EmployeeForm.value).subscribe(res => {
    });
  }

  getDetails = () => {
    this.ss.GetDetails().subscribe(res => {
      this.dataSource = res;
    });
  }
}
