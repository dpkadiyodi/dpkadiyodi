import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  testMsg: Subject<any> = new Subject();
  constructor(private httpClient: HttpClient) { }

  Submit(param): Observable<any> {
    return this.httpClient.post<any>(`/StudentDetails/Employee`, param);
  }

  GetDetails(): Observable<any> {
    return this.httpClient.get<any>(`/GetDetails/Employee`);
  }

}
