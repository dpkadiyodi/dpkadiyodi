export const environment = {
  production: true,
  Api: {
    URL : '192.625.02.2',
    Port: '4100'
  }
};
